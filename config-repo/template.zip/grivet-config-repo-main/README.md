# Grivet spring-boot-microservice-config
Configuration for various Spring Boot modules of [Grivet](https://github.com/fastnsilver/grivet)
